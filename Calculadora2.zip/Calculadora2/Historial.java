import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Historial {
    private List<String> historial = new ArrayList<>();

    public void agregarOperacion(String registro) {
        historial.add(registro);
    }
    public void guardarEnArchivo() {
        try (FileWriter writer = new FileWriter("historial.txt")) {
            for (String registro : historial) {
                writer.write(registro + "\n");
            }
            System.out.println("Historial guardado en 'historial.txt'.");
        } catch (IOException e) {
            System.out.println("Error al guardar el historial: " + e.getMessage());
        }
    }

    public void mostrarHistorial() {
        System.out.println("Historial de operaciones:");
        for (String registro : historial) {
            System.out.println(registro);
        }
    }
}
