public interface Registrable {
    void registrarHistorial();
}
