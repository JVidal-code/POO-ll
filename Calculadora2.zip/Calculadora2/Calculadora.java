public class Calculadora  {
    public double ejecutarOperacion(Operacion operacion){
        //Impriimir el nombre de la operacion a realizar
        System.out.println("La operacion que se realizo:"+ operacion.getNombreOperacion());
        return operacion.calcular();
    }
}
