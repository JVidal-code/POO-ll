public class Raiz extends Operacion {

    public Raiz(double numero1) {
        super(numero1, 0, "Raíz Cuadrada");
    }

    @Override
    public double calcular() {
        if (numero1 < 0) {
            throw new ArithmeticException("No se puede calcular la raíz cuadrada de un número negativo.");
        }
        return Math.sqrt(numero1);
    }
    @Override
    public Object registrarHistorial(){
        System.out.println("[Suma] Operacion:"+ numero1 + "+" + numero2  + " = " + calcular());
                return null;
    }
}
