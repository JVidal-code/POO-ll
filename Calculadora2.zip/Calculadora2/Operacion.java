public abstract class Operacion {
    protected double numero1;
    protected double numero2;
    protected String nombreOperacion;

    public Operacion(double numero1, double numero2, String nombreOperacion) {
        this.numero1 = numero1;
        this.numero2 = numero2;
        this.nombreOperacion = nombreOperacion;
    }

    public abstract double calcular();

    public String getNombreOperacion(){
        return nombreOperacion;
    }
    
    public Object registrarHistorial(){
        return null;
    }
}


