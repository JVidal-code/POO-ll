public class Potencia extends Operacion {

    public Potencia (double numero1, double numero2){
        super(numero1, numero2, "Potencia");
    }
    @Override
    public double calcular (){
        return Math.pow(numero1, numero2);
    }
    @Override
    public Object registrarHistorial(){
        System.out.println("[Suma] Operacion:"+ numero1 + "+" + numero2  + " = " + calcular());
                return null;
    }
}
