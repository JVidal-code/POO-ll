public class Division extends Operacion {

    public Division (double numero1, double numero2){
        super(numero1, numero2,"División");
    }
    @Override
    public double calcular (){
        return numero1 / numero2;
    }
    @Override
    public Object registrarHistorial(){
        System.out.println("[Suma] Operacion:"+ numero1 + "+" + numero2  + " = " + calcular());
                return null;
    }
}

