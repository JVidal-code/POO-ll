import java.util.Scanner;

public class Main {
  /**
 * @param args
 */
public static void main(String[] args) {
      Calculadora calculadora = new Calculadora();
      Scanner scanner = new Scanner(System.in);

      System.out.print("Ingrese el primer número: ");
      double n1 = scanner.nextDouble();

      System.out.print("Ingrese el segundo número: ");
      double n2 = scanner.nextDouble();

      System.out.println("Seleccione operación (+, -, *, /, ^, R): ");
      char operacion = scanner.next().charAt(0);

      Operacion op;

      switch (operacion) {
          case '+':
              op = new Suma(n1, n2);
              break;
          case '-':
              op = new Resta(n1, n2);
              break;
          case '*':
              op = new Multiplicacion(n1, n2);
              break;
          case '/':
              op = new Division(n1, n2);
              break;
          case '^':
              op = new Potencia(n1, n2);
              break;
          case 'R':
              op = new Raiz (n1);
              break;
          default:
              System.out.println("Operación no válida.");
              return;
        }

      double resultado = calculadora.ejecutarOperacion(op); 
      System.out.println("Resultado: " + resultado);
      
      if(op instanceof Registrable){
        ((Registrable) op).registrarHistorial();
      }
    
    Historial historial = new Historial();

    try {
        historial.agregarOperacion(op.getNombreOperacion() + ": " + resultado);
    } catch (Exception e) {
        System.out.println("Entrada inválida: " + e.getMessage());
    }
    historial.mostrarHistorial();
    historial.guardarEnArchivo(); 
}
}


  