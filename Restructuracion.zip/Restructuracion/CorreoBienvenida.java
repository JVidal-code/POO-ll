// DIP: Implementación concreta
public class CorreoBienvenida implements IEnvioCorreo {
    public void enviarBienvenida(Usuario usuario) {
        System.out.println("Enviando correo de bienvenida a: " + usuario.getCorreo());
    }
}
