// OCP + DIP: Interfaz para estrategia de reporte

import java.util.List;

public interface IReporte {
    void generar(List<Usuario> usuarios);
}
