import java.util.ArrayList;
import java.util.List;

public class AlmacenarUsuarios {
    private List<Usuario> usuarios = new ArrayList<>();

    public void guardar(Usuario usuario) {
        usuarios.add(usuario);
        System.out.println("Usuario guardado: " + usuario.getCorreo());
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }
    
}
