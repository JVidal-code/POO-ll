import java.util.List;

public class ReporteEXEL implements IReporte {

    @Override
    public void generar(List<Usuario> usuarios) {
        System.out.println("Generando reporte en Excel para " + usuarios.size() + " usuarios.");  
    }
    
}
