// Main.java
public class Main {
    public static void main(String[] args) {
        AlmacenarUsuarios almacen = new AlmacenarUsuarios();
        ValidadorCorreo validador = new ValidadorCorreo();
        CorreoBienvenida enviador = new CorreoBienvenida(); 
        GestionDeUsuarios gestion = new GestionDeUsuarios(almacen, validador, enviador);

        gestion.agregarUsuario("juan@example.com");
        gestion.agregarUsuario("maria.example.com");

        gestion.generarReporte(new ReportePDF());
        gestion.generarReporte(new ReporteEXEL());

        gestion.enviarCorreoBienvenida("ana@example.com");
        gestion.enviarCorreoBienvenida("anaexample.com");
    }
}
