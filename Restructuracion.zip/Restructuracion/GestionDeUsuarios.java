// Clase principal que orquesta los servicios
public class GestionDeUsuarios {
    private AlmacenarUsuarios almacen;
    private ValidadorCorreo validador;
    private IEnvioCorreo enviador;

    public GestionDeUsuarios(AlmacenarUsuarios alma, ValidadorCorreo val, IEnvioCorreo env) {
        this.almacen = alma;
        this.validador = val;
        this.enviador = env;
    }

    public void agregarUsuario(String correo) {
        if (validador.esValido(correo)) {
            Usuario usuario = new Usuario(correo);
            almacen.guardar(usuario);
        } else {
            System.out.println("Correo inválido: " + correo);
        }
    }

    public void generarReporte(IReporte reporte) {
        reporte.generar(almacen.getUsuarios());
    }

    public void enviarCorreoBienvenida(String correo) {
        if (validador.esValido(correo)) {
            enviador.enviarBienvenida(new Usuario(correo));
        } else {
            System.out.println("Correo inválido para bienvenida: " + correo);
        }
    }
}
