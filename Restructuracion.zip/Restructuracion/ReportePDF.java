import java.util.List;

public class ReportePDF implements IReporte {

    @Override
    public void generar(List<Usuario> usuarios) {        // TODO Auto-generated method stub
        System.out.println("Generando reporte en PDF para " + usuarios.size() + " usuarios.");
    }
}
