// ISP: Interfaz para envío de correos
public interface IEnvioCorreo {
    void enviarBienvenida(Usuario usuario);
}
