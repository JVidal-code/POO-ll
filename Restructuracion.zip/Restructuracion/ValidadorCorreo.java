// SRP + OCP: Servicio de validación de correos
public class ValidadorCorreo {
    public boolean esValido(String correo) {
        return correo.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
    }
}
